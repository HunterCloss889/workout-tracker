import { createClient } from '@supabase/supabase-js';

// Initialize the Supabase client. The project URL and public anon key are
// injected via Vite environment variables. These variables must be
// provided at build time (e.g. via Vercel environment configuration).
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  // Persist the session in localStorage so users remain signed in
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

/**
 * Synchronise an array of objects with a Supabase table. Objects should
 * include an `id` property which is used as the primary key. This helper
 * performs an upsert and ignores any missing fields on existing rows.
 *
 * @param {string} table - The table name to upsert into.
 * @param {Array<Object>} rows - The rows to upsert.
 */
export async function syncTable(table, rows) {
  if (!Array.isArray(rows) || rows.length === 0) return;
  // upsert in batches to avoid exceeding row limits
  const chunkSize = 50;
  for (let i = 0; i < rows.length; i += chunkSize) {
    const chunk = rows.slice(i, i + chunkSize);
    const { error } = await supabase.from(table).upsert(chunk);
    if (error) {
      console.error(`Supabase upsert error for table ${table}:`, error.message);
    }
  }
}
