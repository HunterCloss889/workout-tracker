import React, { useEffect, useMemo, useState } from "react";
import {
  Dumbbell,
  CalendarDays,
  Plus,
  Trash2,
  Save,
  X,
  ChevronRight,
  Scale,
  BarChart2,
  History as HistoryIcon,
  Home,
} from "lucide-react";
import {
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  ScatterChart,
  Scatter,
} from "recharts";

// ---------------------------------------------
// Utilities
// ---------------------------------------------
const fmtDate = (iso) => new Date(iso).toLocaleDateString();
const todayISO = () => new Date().toISOString().slice(0, 10);
const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

// Local Storage Keys
const LS_KEYS = {
  routines: "wt_routines",
  logs: "wt_logs",
  weights: "wt_bodyweights",
};

const loadLS = (key, fallback) => {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return fallback;
    return parsed;
  } catch {
    return fallback;
  }
};
const saveLS = (key, value) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {}
};

// ---------------------------------------------
// Main App
// ---------------------------------------------
export default function WorkoutTrackerApp() {
  const [tab, setTab] = useState("routines");

  // Routines
  const [routines, setRoutines] = useState(() => loadLS(LS_KEYS.routines, []));
  useEffect(() => saveLS(LS_KEYS.routines, routines), [routines]);

  // Logs
  const [logs, setLogs] = useState(() => loadLS(LS_KEYS.logs, []));
  useEffect(() => saveLS(LS_KEYS.logs, logs), [logs]);

  // Body weight
  const [weights, setWeights] = useState(() => loadLS(LS_KEYS.weights, []));
  useEffect(() => saveLS(LS_KEYS.weights, weights), [weights]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 relative">
      <BackgroundArt />

      <header className="sticky top-0 z-30 backdrop-blur bg-slate-950/70 border-b border-slate-800">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-3">
          <Dumbbell className="w-6 h-6 text-indigo-400" />
          <h1 className="text-xl font-semibold tracking-tight">Workout Tracker</h1>
          <nav className="ml-auto flex gap-1 text-sm">
            <NavTab
              icon={<Home className="w-4 h-4" />}
              label="Routines"
              active={tab === "routines"}
              onClick={() => setTab("routines")}
            />
            <NavTab
              icon={<CalendarDays className="w-4 h-4" />}
              label="Log"
              active={tab === "log"}
              onClick={() => setTab("log")}
            />
            <NavTab
              icon={<HistoryIcon className="w-4 h-4" />}
              label="History"
              active={tab === "history"}
              onClick={() => setTab("history")}
            />
            <NavTab
              icon={<BarChart2 className="w-4 h-4" />}
              label="Progress"
              active={tab === "progress"}
              onClick={() => setTab("progress")}
            />
            <NavTab
              icon={<Scale className="w-4 h-4" />}
              label="Body Weight"
              active={tab === "weight"}
              onClick={() => setTab("weight")}
            />
          </nav>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6">
        {tab === "routines" && (
          <RoutinesPage routines={routines} setRoutines={setRoutines} />
        )}
        {tab === "log" && (
          <LogPage routines={routines} logs={logs} setLogs={setLogs} />
        )}
        {tab === "history" && <HistoryPage logs={logs} routines={routines} />}
        {tab === "progress" && <ProgressPage logs={logs} routines={routines} />}
        {tab === "weight" && <WeightPage weights={weights} setWeights={setWeights} />}
      </main>

      <footer className="max-w-6xl mx-auto px-4 pb-8 text-xs text-slate-400">
        <p>
          Data is stored locally in your browser (no accounts needed). You can clear
          it anytime with your browser storage settings.
        </p>
      </footer>
    </div>
  );
}

function NavTab({ icon, label, active, onClick }) {
  return (
    <button
      onClick={onClick}
      className={
        "inline-flex items-center gap-2 px-3 py-2 rounded-xl transition border " +
        (active
          ? "bg-indigo-500/20 text-indigo-300 border-indigo-600/40"
          : "hover:bg-slate-800/60 border-slate-800 text-slate-300 hover:text-white")
      }
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}

// ---------------------------------------------
// Background Art (cartoon equipment)
// ---------------------------------------------
function BackgroundArt() {
  return (
    <div
      aria-hidden
      className="pointer-events-none absolute inset-0 -z-10"
      style={{
        backgroundImage:
          "radial-gradient(1000px 600px at 80% -10%, rgba(99,102,241,0.15), transparent), radial-gradient(800px 500px at 10% -20%, rgba(56,189,248,0.12), transparent)",
      }}
    >
      <svg
        className="absolute inset-0 w-full h-full opacity-20"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <pattern
            id="gym"
            x="0"
            y="0"
            width="120"
            height="120"
            patternUnits="userSpaceOnUse"
          >
            <g
              fill="none"
              stroke="#94a3b8"
              strokeWidth="1.5"
              strokeOpacity="0.25"
            >
              <rect x="8" y="50" width="24" height="20" rx="4" />
              <rect x="88" y="50" width="24" height="20" rx="4" />
              <rect x="40" y="56" width="40" height="8" rx="4" />
              <circle cx="60" cy="20" r="10" />
              <line x1="60" y1="30" x2="60" y2="44" />
              <rect x="52" y="44" width="16" height="6" rx="3" />
            </g>
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#gym)" />
      </svg>
    </div>
  );
}

// ---------------------------------------------
// Routines Page
// ---------------------------------------------
function RoutinesPage({ routines, setRoutines }) {
  const [name, setName] = useState("");
  const [exerciseAdd, setExerciseAdd] = useState("");
  const [selectedId, setSelectedId] = useState(null);

  const selected = routines.find((r) => r.id === selectedId) || null;

  const createRoutine = () => {
    const trimmed = name.trim();
    if (!trimmed) return;
    if (routines.some((r) => r.name.toLowerCase() === trimmed.toLowerCase())) {
      alert("A day with this name already exists.");
      return;
    }
    const r = { id: uid(), name: trimmed, exercises: [], createdAt: new Date().toISOString() };
    setRoutines([r, ...routines]);
    setName("");
    setSelectedId(r.id);
  };

  const removeRoutine = (id) => {
    if (!confirm("Delete this workout day? This cannot be undone.")) return;
    setRoutines(routines.filter((r) => r.id !== id));
    if (selectedId === id) setSelectedId(null);
  };

  const addExercise = () => {
    if (!selected) return;
    const ex = exerciseAdd.trim();
    if (!ex) return;
    if (selected.exercises.some((e) => e.toLowerCase() === ex.toLowerCase())) {
      alert("That exercise already exists in this day.");
      return;
    }
    const updated = routines.map((r) =>
      r.id === selected.id ? { ...r, exercises: [...r.exercises, ex] } : r
    );
    setRoutines(updated);
    setExerciseAdd("");
  };

  const removeExercise = (ex) => {
    if (!selected) return;
    const updated = routines.map((r) =>
      r.id === selected.id ? { ...r, exercises: r.exercises.filter((e) => e !== ex) } : r
    );
    setRoutines(updated);
  };

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <section className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4">
        <h2 className="text-lg font-semibold mb-3">Create a Workout Day</h2>
        <div className="flex gap-2">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g., Back & Bi, Chest & Tri, Legs & Shoulders"
            className="flex-1 bg-slate-800/70 border border-slate-700 rounded-xl px-3 py-2 outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <button
            onClick={createRoutine}
            className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-3 py-2 rounded-xl"
          >
            <Plus className="w-4 h-4" /> Add
          </button>
        </div>

        <h3 className="mt-6 mb-2 text-sm uppercase tracking-wide text-slate-400">Your Days</h3>
        <div className="space-y-2 max-h-[22rem] overflow-y-auto pr-1">
          {routines.length === 0 && (
            <p className="text-slate-400">No days yet. Create one to get started.</p>
          )}
          {routines.map((r) => (
            <button
              key={r.id}
              onClick={() => setSelectedId(r.id)}
              className={
                "w-full text-left px-3 py-2 rounded-xl border transition flex items-center justify-between " +
                (selectedId === r.id
                  ? "bg-slate-800/80 border-slate-700"
                  : "hover:bg-slate-800/40 border-slate-800")
              }
            >
              <div>
                <div className="font-medium">{r.name}</div>
                <div className="text-xs text-slate-400">Created {fmtDate(r.createdAt)}</div>
              </div>
              <Trash2
                onClick={(e) => {
                  e.stopPropagation();
                  removeRoutine(r.id);
                }}
                className="w-4 h-4 text-slate-400 hover:text-red-400"
              />
            </button>
          ))}
        </div>
      </section>

      <section className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4">
        <h2 className="text-lg font-semibold mb-3">Exercises in Selected Day</h2>
        {!selected ? (
          <p className="text-slate-400">Select a workout day to add exercises.</p>
        ) : (
          <>
            <div className="flex gap-2 mb-3">
              <input
                value={exerciseAdd}
                onChange={(e) => setExerciseAdd(e.target.value)}
                placeholder="e.g., Preacher Curl"
                className="flex-1 bg-slate-800/70 border border-slate-700 rounded-xl px-3 py-2 outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <button
                onClick={addExercise}
                className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-3 py-2 rounded-xl"
              >
                <Plus className="w-4 h-4" /> Add Exercise
              </button>
            </div>
            {selected.exercises.length === 0 ? (
              <p className="text-slate-400">
                No exercises yet for <span className="text-slate-200 font-medium">{selected.name}</span>.
              </p>
            ) : (
              <ul className="space-y-2">
                {selected.exercises.map((ex) => (
                  <li key={ex} className="flex items-center justify-between px-3 py-2 rounded-xl border border-slate-800 bg-slate-800/40">
                    <span>{ex}</span>
                    <button onClick={() => removeExercise(ex)} className="text-slate-400 hover:text-red-400">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </>
        )}
      </section>
    </div>
  );
}

// ---------------------------------------------
// Log Page
// ---------------------------------------------
function LogPage({ routines, logs, setLogs }) {
  const [routineId, setRoutineId] = useState("");
  const [date, setDate] = useState(todayISO());

  const routine = routines.find((r) => r.id === routineId) || null;

  // logState: { [exercise]: [{weight:"", reps:""}, ...] }
  const [logState, setLogState] = useState({});

  useEffect(() => {
    // Reset state when routine changes
    if (routine) {
      const init = {};
      for (const ex of routine.exercises) init[ex] = [{ weight: "", reps: "" }];
      setLogState(init);
    } else {
      setLogState({});
    }
  }, [routineId]);

  const handleSetChange = (ex, idx, field, value) => {
    setLogState((prev) => {
      const sets = prev[ex] ? [...prev[ex]] : [{ weight: "", reps: "" }];
      sets[idx] = { ...sets[idx], [field]: value };
      // Auto-create next set if last set has both values
      const last = sets[sets.length - 1];
      const lastComplete = last && Number(last.weight) > 0 && Number(last.reps) > 0;
      if (lastComplete && sets.length < 10) {
        sets.push({ weight: "", reps: "" });
      }
      return { ...prev, [ex]: sets };
    });
  };

  const validSets = (sets) =>
    sets.filter((s) => Number(s.weight) > 0 && Number(s.reps) > 0);

  const canSave = useMemo(() => {
    if (!routine) return false;
    const some = routine.exercises.some((ex) => validSets(logState[ex] || []).length > 0);
    return some;
  }, [routine, logState]);

  const saveLog = () => {
    if (!routine) return;
    const entries = routine.exercises.map((ex) => ({
      exercise: ex,
      sets: validSets(logState[ex] || []),
    }));
    const cleaned = entries.filter((e) => e.sets.length > 0);
    if (cleaned.length === 0) {
      alert("Add at least one set before saving.");
      return;
    }
    const log = {
      id: uid(),
      routineId: routine.id,
      routineName: routine.name,
      dateISO: new Date(date + "T12:00:00").toISOString(),
      entries: cleaned,
      createdAt: new Date().toISOString(),
    };
    setLogs([log, ...logs]);
    // Reset
    setRoutineId("");
    setDate(todayISO());
    setLogState({});
    alert("Workout saved!");
  };

  const discard = () => {
    if (!confirm("Discard current log?")) return;
    setRoutineId("");
    setDate(todayISO());
    setLogState({});
  };

  return (
    <div className="space-y-4">
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4">
        <h2 className="text-lg font-semibold mb-3">Add a Log</h2>
        <div className="grid sm:grid-cols-3 gap-3">
          <div className="sm:col-span-2">
            <label className="text-sm text-slate-300">Workout Day</label>
            <select
              value={routineId}
              onChange={(e) => setRoutineId(e.target.value)}
              className="mt-1 w-full bg-slate-800/70 border border-slate-700 rounded-xl px-3 py-2"
            >
              <option value="">Select a day…</option>
              {routines.map((r) => (
                <option key={r.id} value={r.id}>{r.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-sm text-slate-300">Date</label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="mt-1 w-full bg-slate-800/70 border border-slate-700 rounded-xl px-3 py-2"
            />
          </div>
        </div>
      </div>

      {routine && (
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4">
          <h3 className="font-semibold mb-2">{routine.name} — Exercises</h3>
          {routine.exercises.length === 0 ? (
            <p className="text-slate-400">This day has no exercises. Add some in the Routines tab.</p>
          ) : (
            <div className="space-y-6">
              {routine.exercises.map((ex) => (
                <ExerciseLogEditor
                  key={ex}
                  name={ex}
                  sets={logState[ex] || [{ weight: "", reps: "" }]}
                  onChange={(idx, field, value) => handleSetChange(ex, idx, field, value)}
                />
              ))}
            </div>
          )}
          <div className="flex gap-2 mt-6">
            <button
              onClick={saveLog}
              disabled={!canSave}
              className={
                "inline-flex items-center gap-2 px-4 py-2 rounded-xl border transition " +
                (canSave
                  ? "bg-emerald-600 hover:bg-emerald-500 border-emerald-500 text-white"
                  : "bg-slate-800 border-slate-700 text-slate-400 cursor-not-allowed")
              }
            >
              <Save className="w-4 h-4" /> Save Log
            </button>
            <button onClick={discard} className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-700 hover:bg-slate-800/60">
              <X className="w-4 h-4" /> Discard
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function ExerciseLogEditor({ name, sets, onChange }) {
  return (
    <div className="border border-slate-800 rounded-2xl p-3 bg-slate-800/30">
      <div className="font-medium mb-2 flex items-center gap-2">
        <ChevronRight className="w-4 h-4 text-slate-400" /> {name}
      </div>
      <div className="grid grid-cols-3 sm:grid-cols-5 gap-2 items-end">
        <div className="col-span-1 text-xs text-slate-400">Set #</div>
        <div className="col-span-1 text-xs text-slate-400">Weight (lb)</div>
        <div className="col-span-1 text-xs text-slate-400">Reps</div>
        <div className="hidden sm:block col-span-2 text-xs text-slate-400">&nbsp;</div>
        {sets.map((set, idx) => (
          <React.Fragment key={idx}>
            <div className="col-span-1">
              <div className="px-3 py-2 border border-slate-700 rounded-lg bg-slate-900/50 text-center">{idx + 1}</div>
            </div>
            <div className="col-span-1">
              <input
                inputMode="decimal"
                value={set.weight}
                onChange={(e) => onChange(idx, "weight", e.target.value.replace(/[^0-9.]/g, ""))}
                placeholder="0"
                className="w-full bg-slate-900/50 border border-slate-700 rounded-lg px-3 py-2"
              />
            </div>
            <div className="col-span-1">
              <input
                inputMode="numeric"
                value={set.reps}
                onChange={(e) => onChange(idx, "reps", e.target.value.replace(/[^0-9]/g, ""))}
                placeholder="0"
                className="w-full bg-slate-900/50 border border-slate-700 rounded-lg px-3 py-2"
              />
            </div>
            <div className="hidden sm:block col-span-2 text-xs text-slate-500">Enter both weight and reps to unlock next set (up to 10).</div>
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}

// ---------------------------------------------
// History Page
// ---------------------------------------------
function HistoryPage({ logs, routines }) {
  const [filter, setFilter] = useState("");
  const filtered = useMemo(() => {
    const arr = [...logs].sort((a, b) => new Date(b.dateISO) - new Date(a.dateISO));
    if (!filter) return arr;
    return arr.filter((l) => l.routineId === filter);
  }, [logs, filter]);

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-end gap-3 bg-slate-900/60 border border-slate-800 rounded-2xl p-4">
        <div className="flex-1 min-w-[240px]">
          <label className="text-sm text-slate-300">Filter by Workout Day</label>
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="mt-1 w-full bg-slate-800/70 border border-slate-700 rounded-xl px-3 py-2"
          >
            <option value="">All days</option>
            {routines.map((r) => (
              <option key={r.id} value={r.id}>{r.name}</option>
            ))}
          </select>
        </div>
        <div className="text-sm text-slate-400">Sorted newest → oldest</div>
      </div>

      {filtered.length === 0 ? (
        <p className="text-slate-400">No logs yet.</p>
      ) : (
        <div className="space-y-4">
          {filtered.map((log) => (
            <div key={log.id} className="border border-slate-800 rounded-2xl p-4 bg-slate-900/60">
              <div className="flex items-center justify-between mb-2">
                <div className="font-semibold">{log.routineName}</div>
                <div className="text-sm text-slate-400">{fmtDate(log.dateISO)}</div>
              </div>
              <div className="space-y-2">
                {log.entries.map((e) => (
                  <div key={e.exercise} className="bg-slate-800/40 rounded-xl p-3">
                    <div className="font-medium mb-1">{e.exercise}</div>
                    <div className="text-sm text-slate-300 flex flex-wrap gap-x-4 gap-y-1">
                      {e.sets.map((s, i) => (
                        <span key={i} className="inline-flex items-center gap-1"><span className="text-slate-400">Set {i + 1}:</span> {Number(s.weight)} lb × {Number(s.reps)} reps</span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------
// Progress Page
// ---------------------------------------------
function ProgressPage({ logs, routines }) {
  const [selectedRoutineId, setSelectedRoutineId] = useState("");
  const routine = routines.find((r) => r.id === selectedRoutineId) || null;
  const [selectedExercise, setSelectedExercise] = useState("");

  useEffect(() => setSelectedExercise(""), [selectedRoutineId]);

  const data = useMemo(() => {
    if (!routine || !selectedExercise) return [];
    const relevant = logs.filter((l) => l.routineId === routine.id);
    const points = relevant.map((l) => {
      const entry = l.entries.find((e) => e.exercise === selectedExercise);
      if (!entry) return null;
      const candidates = entry.sets.filter((s) => Number(s.reps) >= 10);
      if (candidates.length === 0) return null;
      const maxWeight = Math.max(...candidates.map((s) => Number(s.weight)));
      return { date: new Date(l.dateISO).getTime(), dateLabel: fmtDate(l.dateISO), weight: maxWeight };
    }).filter(Boolean);
    // Sort by date ascending for chart
    points.sort((a, b) => a.date - b.date);
    return points;
  }, [logs, routine, selectedExercise]);

  return (
    <div className="space-y-4">
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4">
        <h2 className="text-lg font-semibold mb-3">Track Progress (10+ rep max weight)</h2>
        <div className="grid md:grid-cols-2 gap-3">
          <div>
            <label className="text-sm text-slate-300">Workout Day</label>
            <select
              value={selectedRoutineId}
              onChange={(e) => setSelectedRoutineId(e.target.value)}
              className="mt-1 w-full bg-slate-800/70 border border-slate-700 rounded-xl px-3 py-2"
            >
              <option value="">Select a day…</option>
              {routines.map((r) => (
                <option key={r.id} value={r.id}>{r.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-sm text-slate-300">Exercise</label>
            <select
              value={selectedExercise}
              onChange={(e) => setSelectedExercise(e.target.value)}
              disabled={!routine}
              className="mt-1 w-full bg-slate-800/70 border border-slate-700 rounded-xl px-3 py-2 disabled:opacity-50"
            >
              <option value="">{routine ? "Select an exercise…" : "Select a day first"}</option>
              {routine?.exercises.map((ex) => (
                <option key={ex} value={ex}>{ex}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="border border-slate-800 rounded-2xl p-4 bg-slate-900/60">
        {data.length === 0 ? (
          <p className="text-slate-400">No qualifying (10+ reps) data yet for this exercise.</p>
        ) : (
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 10, right: 20, left: 0, bottom: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#0f172a" />
                <XAxis
                  type="number"
                  dataKey="date"
                  scale="time"
                  domain={[data[0].date, data[data.length - 1].date]}
                  tickFormatter={(v) => new Date(v).toLocaleDateString()}
                  stroke="#94a3b8"
                />
                <YAxis dataKey="weight" stroke="#94a3b8" unit=" lb" />
                <Tooltip
                  labelFormatter={() => ""}
                  formatter={(value, name, props) => {
                    if (name === "weight") return [value + " lb", props.payload.dateLabel];
                    return value;
                  }}
                />
                <Scatter data={data} fill="#6366f1" />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>
      <p className="text-xs text-slate-400">Rule: for each workout day, we plot the heaviest set where reps ≥ 10. If no set hit 10 reps, that day is left blank.</p>
    </div>
  );
}

// ---------------------------------------------
// Body Weight Page
// ---------------------------------------------
function WeightPage({ weights, setWeights }) {
  const [val, setVal] = useState("");
  const [span, setSpan] = useState("3m"); // default 3 months

  const addWeight = () => {
    const w = Number(val);
    if (!w || w <= 0) return;
    const entry = { id: uid(), dateISO: new Date().toISOString(), weight: Number(w.toFixed(1)) };
    setWeights([entry, ...weights]);
    setVal("");
  };

  const filtered = useMemo(() => {
    const now = new Date();
    let earliest = new Date(0);
    if (span !== "all") {
      const d = new Date(now);
      if (span === "1w") d.setDate(d.getDate() - 7);
      if (span === "1m") d.setMonth(d.getMonth() - 1);
      if (span === "3m") d.setMonth(d.getMonth() - 3);
      if (span === "6m") d.setMonth(d.getMonth() - 6);
      if (span === "1y") d.setFullYear(d.getFullYear() - 1);
      earliest = d;
    }
    const arr = [...weights]
      .filter((e) => new Date(e.dateISO) >= earliest)
      .sort((a, b) => new Date(a.dateISO) - new Date(b.dateISO))
      .map((e) => ({
        date: new Date(e.dateISO).getTime(),
        dateLabel: fmtDate(e.dateISO),
        weight: e.weight,
      }));
    return arr;
  }, [weights, span]);

  return (
    <div className="space-y-4">
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4">
        <h2 className="text-lg font-semibold mb-3">Body Weight</h2>
        <div className="grid sm:grid-cols-3 gap-3 items-end">
          <div className="sm:col-span-2">
            <label className="text-sm text-slate-300">Enter weight (lb)</label>
            <div className="mt-1 flex gap-2">
              <input
                value={val}
                onChange={(e) => setVal(e.target.value.replace(/[^0-9.]/g, ""))}
                placeholder="e.g., 182.4"
                className="flex-1 bg-slate-800/70 border border-slate-700 rounded-xl px-3 py-2"
              />
              <button onClick={addWeight} className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-3 py-2 rounded-xl">
                <Plus className="w-4 h-4" /> Add
              </button>
            </div>
          </div>
          <div>
            <label className="text-sm text-slate-300">Time span</label>
            <select value={span} onChange={(e) => setSpan(e.target.value)} className="mt-1 w-full bg-slate-800/70 border border-slate-700 rounded-xl px-3 py-2">
              <option value="1w">1 week</option>
              <option value="1m">1 month</option>
              <option value="3m">3 months</option>
              <option value="6m">6 months</option>
              <option value="1y">1 year</option>
              <option value="all">All</option>
            </select>
          </div>
        </div>
      </div>

      <div className="border border-slate-800 rounded-2xl p-4 bg-slate-900/60">
        {filtered.length === 0 ? (
          <p className="text-slate-400">No entries for this time span.</p>
        ) : (
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={filtered} margin={{ top: 10, right: 20, left: 0, bottom: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#0f172a" />
                <XAxis
                  dataKey="date"
                  type="number"
                  scale="time"
                  tickFormatter={(v) => new Date(v).toLocaleDateString()}
                  stroke="#94a3b8"
                />
                <YAxis unit=" lb" stroke="#94a3b8" />
                <Tooltip
                  labelFormatter={() => ""}
                  formatter={(value, name, props) => {
                    if (name === "weight") return [value + " lb", props.payload.dateLabel];
                    return value;
                  }}
                />
                <Line dataKey="weight" dot stroke="#22d3ee" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>
    </div>
  );
}